/*
 * globals.h
 *
 *  Created on: Jan 30, 2025
 *      Author: Borna
 */

#ifndef GLOBALS_H
#define GLOBALS_H

extern int fault;

#endif
